import os
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler


data_path = "titanic.csv"


def main():
    df = pd.read_csv(data_path)

    num_cols = df.select_dtypes(include=['int64','float64']).columns
    cat_cols = df.select_dtypes(include=['object','category']).columns

    df[num_cols] = SimpleImputer(strategy='median').fit_transform(df[num_cols])
    df[cat_cols] = SimpleImputer(strategy='most_frequent').fit_transform(df[cat_cols])

    for col in ['Sex','Embarked']:
        if col in df.columns:
            df = pd.get_dummies(df, columns=[col], drop_first=True)

    if 'SibSp' in df.columns and 'Parch' in df.columns:
        df['FamilySize'] = df['SibSp'] + df['Parch'] + 1

    if 'Fare' in df.columns:
        Q1 = df['Fare'].quantile(0.25)
        Q3 = df['Fare'].quantile(0.75)
        IQR = Q3 - Q1
        df = df[~((df['Fare'] < (Q1 - 1.5*IQR)) | (df['Fare'] > (Q3 + 1.5*IQR)))]

    scale_cols = [c for c in ['Age','Fare'] if c in df.columns]
    df[scale_cols] = StandardScaler().fit_transform(df[scale_cols])

    
    out_path = "../titanic_clean.csv"

    df.to_csv(out_path, index=False)

    print("Cleaned dataset saved at:", out_path)
    

if __name__ == "__main__":
    main()
